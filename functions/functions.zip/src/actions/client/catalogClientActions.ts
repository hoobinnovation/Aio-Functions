import { v4 as uuidv4 } from 'uuid';
import { EntityManager } from 'typeorm';
import { ActionContext } from '../../core/protocol';
import { UserProductFavorite } from '../../entities/UserProductFavorite';
import { UserStoreFavorite } from '../../entities/UserStoreFavorite';
import { normalizeListQueryInput } from '../../utils/queryNormalization';
import { buildHomeLayout } from '../home/homeBuilder';
import { Category } from '../../entities/Category';
import { Product } from '../../entities/Product';
import { requireAccountIdentity } from '../../core/identity';
import { recomputeProductMetrics } from '../productMetrics';
import { resolveStoreVisibleCategories, resolveStoreVisibleProducts } from '../catalogResolver';

const CLIENT_PRODUCT_QUERY_CONTRACT = {
    allowedSortFields: ['sort.by','createdAt', 'updatedAt', 'name', 'slug', 'categoryId', 'ratingAverage', 'popularityScore'],
    sortAliases: {
        newest: { by: 'createdAt', direction: 'desc' as const },
        oldest: { by: 'createdAt', direction: 'asc' as const },
        recentlyUpdated: { by: 'updatedAt', direction: 'desc' as const },
        nameAsc: { by: 'name', direction: 'asc' as const },
        nameDesc: { by: 'name', direction: 'desc' as const },
        topRated: { by: 'ratingAverage', direction: 'desc' as const },
        mostPopular: { by: 'popularityScore', direction: 'desc' as const },
    },
    allowedFilterKeys: ['categoryId'],
    allowedGroupByKeys: ['categoryId'],
    allowedColumns: ['id', 'storeId', 'categoryId', 'name', 'slug', 'description', 'ratingAverage', 'ratingCount', 'favoriteCount', 'completedOrderQty', 'popularityScore', 'createdAt', 'updatedAt'],
};

export async function homeGetLayout(ctx: ActionContext, payload: any = {}) {
    return buildHomeLayout(ctx, payload);
}

export async function catalogGetCategories(ctx: ActionContext) {
    const categories = await resolveStoreVisibleCategories(ctx.db, ctx.storeId!, false);

    return {
        categories,
    };
}

export async function catalogListProducts(ctx: ActionContext, payload: any = {}) {
    const q = normalizeListQueryInput(payload, {
        defaultPageSize: 20,
        maxPageSize: 200,
        defaultSort: { by: 'updatedAt', dir: 'desc' },
        contract: CLIENT_PRODUCT_QUERY_CONTRACT,
    });

    const { rows: products, total } = await resolveStoreVisibleProducts(ctx.db, ctx.storeId!, {
        includeDisabled: false,
        categoryId: typeof payload.categoryId === 'string' && payload.categoryId.trim() ? payload.categoryId : undefined,
        sortBy: q.sort.by,
        sortDirection: q.sort.direction === 'asc' ? 'ASC' : 'DESC',
        limit: q.limit,
        offset: q.offset,
    });

    return {
        products,
        total,
        page: q.page,
        pageSize: q.pageSize,
        pagination: {
            page: q.page,
            pageSize: q.pageSize,
            total,
            hasMore: q.offset + products.length < total,
        },
    };
}

export async function productFavoritesList(ctx: ActionContext, payload: any = {}) {
    const uid = requireAccountIdentity(ctx);
    const q = normalizeListQueryInput(payload, { defaultPageSize: 20, maxPageSize: 200 });
    const rows = await ctx.db.getRepository(UserProductFavorite).find({
        where: { uid },
        order: { createdAt: 'DESC' as any },
        take: q.limit,
        skip: q.offset,
    });

    return { favorites: rows };
}

export async function productFavoritesToggle(ctx: ActionContext, payload: any) {
    const repo = ctx.db.getRepository(UserProductFavorite);
    const uid = requireAccountIdentity(ctx);
    const existing = await repo.findOneBy({ uid, productId: payload.productId });

    if (existing) {
        await ctx.db.transaction(async (tx: EntityManager) => {
            await tx.getRepository(UserProductFavorite).delete({ id: existing.id });
            await recomputeProductMetrics(tx, payload.productId, ctx.storeId!);
        });
        return { favorited: false };
    }

    await ctx.db.transaction(async (tx: EntityManager) => {
        await tx.getRepository(UserProductFavorite).save(
            tx.getRepository(UserProductFavorite).create({
                id: uuidv4(),
                uid,
                productId: payload.productId,
            })
        );
        await recomputeProductMetrics(tx, payload.productId, ctx.storeId!);
    });

    return { favorited: true };
}

export async function storeFavoritesList(ctx: ActionContext, payload: any = {}) {
    const uid = requireAccountIdentity(ctx);
    const q = normalizeListQueryInput(payload, { defaultPageSize: 20, maxPageSize: 200 });
    const rows = await ctx.db.getRepository(UserStoreFavorite).find({
        where: { uid },
        order: { createdAt: 'DESC' as any },
        take: q.limit,
        skip: q.offset,
    });

    return { favorites: rows };
}

export async function storeFavoritesToggle(ctx: ActionContext, payload: any) {
    const repo = ctx.db.getRepository(UserStoreFavorite);
    const uid = requireAccountIdentity(ctx);
    const existing = await repo.findOneBy({ uid, storeId: payload.storeId });

    if (existing) {
        await ctx.db.transaction(async (tx: EntityManager) => {
            await tx.getRepository(UserStoreFavorite).delete({ id: existing.id });
        });
        return { favorited: false };
    }

    await ctx.db.transaction(async (tx: EntityManager) => {
        await tx.getRepository(UserStoreFavorite).save(
            tx.getRepository(UserStoreFavorite).create({
                id: uuidv4(),
                uid,
                storeId: payload.storeId,
            })
        );
    });

    return { favorited: true };
}
