import { EntityManager } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';
import { ActionContext } from '../../core/protocol';
import { actionsListForGateway } from '../../health/actionsHealth';
import { MediaAsset } from '../../entities/MediaAsset';
import { AppError } from '../../core/errors';
import { getBucketName, getStorage } from '../../utils/storage';
import { UserProfile } from '../../entities/UserProfile';
import { UserAddress } from '../../entities/UserAddress';
import { UserAccountDeleteRequest } from '../../entities/UserAccountDeleteRequest';
import { Store } from '../../entities/Store';
import { UserStoreContext } from '../../entities/UserStoreContext';
import { ensureUserProfileForUid, requireAccountIdentity, requireSessionIdentity } from '../../core/identity';
import { buildProviderStateSnapshot } from '../../core/auth/providerState';
import { presentUserProfile, resolveDisplayNameInput } from '../../core/auth/profileShape';
import { createMediaUploadSpec } from '../../utils/mediaUploadSpec';

async function requireProfile(ctx: ActionContext): Promise<UserProfile> {
  const uid = requireSessionIdentity(ctx);
  const p = await ctx.db.getRepository(UserProfile).findOneBy({ uid });
  if (!p) throw new AppError('NOT_FOUND', 'User profile not found');
  return p;
}

async function requireActiveProfileForWrite(ctx: ActionContext): Promise<UserProfile> {
  const p = await requireProfile(ctx);
  if (p.status !== 'active') throw new AppError('ACCOUNT_DISABLED', 'Profile is not active');
  return p;
}

export async function clientHealthWhoAmI(ctx: ActionContext) {
  return { uid: ctx.uid, gateway: ctx.gateway, identityType: ctx.auth?.isAnonymous ? 'guestAnonymous' : 'authenticatedCustomer' };
}

export async function clientActionsList() {
  return {
    gateway: 'client',
    allowedActions: actionsListForGateway('client'),
  };
}

export async function authEnsureUserProfile(ctx: ActionContext) {
  const uid = requireSessionIdentity(ctx);
  const profile = await ctx.db.transaction(async (tx: EntityManager) => ensureUserProfileForUid(tx, uid));
  const providers = await ctx.db.transaction(async (tx: EntityManager) => buildProviderStateSnapshot(tx, uid));
  return {
    profile: presentUserProfile(profile),
    providers,
    identityType: ctx.auth?.isAnonymous ? 'guestAnonymous' : 'authenticatedCustomer',
  };
}

export async function profileGet(ctx: ActionContext) {
  const uid = requireAccountIdentity(ctx);
  const profile = await ctx.db.transaction(async (tx: EntityManager) => ensureUserProfileForUid(tx, uid));
  return { profile: presentUserProfile(profile) };
}

export async function profileUpdate(ctx: ActionContext, payload: any) {
  const uid = requireAccountIdentity(ctx);
  await requireActiveProfileForWrite(ctx);
  await ctx.db.transaction(async (tx: EntityManager) => {
    await tx.getRepository(UserProfile).update({ uid }, {
      phone: payload.phone ?? null,
      email: payload.email ?? null,
      displayName: resolveDisplayNameInput(payload),
      locale: payload.locale ?? null,
      marketingOptIn: payload.marketingOptIn ?? false,
    });
  });
  return profileGet(ctx);
}

export async function accountDeleteRequest(ctx: ActionContext, payload: any) {
  const uid = requireAccountIdentity(ctx);
  await requireProfile(ctx);
  const repo = ctx.db.getRepository(UserAccountDeleteRequest);
  const existing = await repo.findOne({ where: { uid, status: 'pending' } })
    || await repo.findOne({ where: { uid, status: 'approved' } });
  if (existing) return { request: existing, idempotent: true };

  const id = uuidv4();
  await ctx.db.transaction(async (tx: EntityManager) => {
    const req = tx.getRepository(UserAccountDeleteRequest).create({
      id,
      uid,
      reason: payload.reason ?? null,
      status: 'pending',
      requestedAt: new Date(),
      reviewedAt: null,
      reviewedByUid: null,
    });
    await tx.getRepository(UserAccountDeleteRequest).save(req);
    await tx.getRepository(UserProfile).update({ uid }, { status: 'deleted_pending' });
  });
  const created = await repo.findOneByOrFail({ id });
  return { request: created, idempotent: false };
}

export async function addressesList(ctx: ActionContext) {
  const uid = requireAccountIdentity(ctx);
  const rows = await ctx.db.getRepository(UserAddress).find({ where: { uid }, order: { updatedAt: 'DESC' as any } });
  return { addresses: rows };
}

export async function addressesCreate(ctx: ActionContext, payload: any) {
  const uid = requireAccountIdentity(ctx);
  await requireActiveProfileForWrite(ctx);
  const id = uuidv4();
  await ctx.db.transaction(async (tx: EntityManager) => {
    if (payload.isDefault) {
      await tx.getRepository(UserAddress).update({ uid }, { isDefault: false });
    }
    const row = tx.getRepository(UserAddress).create({ ...payload, id, uid, isDefault: !!payload.isDefault });
    await tx.getRepository(UserAddress).save(row);
  });
  return { address: await ctx.db.getRepository(UserAddress).findOneByOrFail({ id }) };
}

export async function addressesUpdate(ctx: ActionContext, payload: any) {
  const uid = requireAccountIdentity(ctx);
  await requireActiveProfileForWrite(ctx);
  const existing = await ctx.db.getRepository(UserAddress).findOneBy({ id: payload.id, uid });
  if (!existing) throw new AppError('NOT_FOUND', 'Address not found');
  await ctx.db.transaction(async (tx: EntityManager) => {
    if (payload.isDefault) {
      await tx.getRepository(UserAddress).update({ uid }, { isDefault: false });
    }
    await tx.getRepository(UserAddress).update({ id: payload.id, uid }, { ...payload, isDefault: payload.isDefault ?? existing.isDefault });
  });
  return { address: await ctx.db.getRepository(UserAddress).findOneByOrFail({ id: payload.id }) };
}

export async function addressesDelete(ctx: ActionContext, payload: any) {
  const uid = requireAccountIdentity(ctx);
  await requireActiveProfileForWrite(ctx);
  await ctx.db.transaction(async (tx: EntityManager) => {
    const res = await tx.getRepository(UserAddress).delete({ id: payload.id, uid });
    if (!res.affected) throw new AppError('NOT_FOUND', 'Address not found');
  });
  return { deleted: true };
}

export async function addressesSetDefault(ctx: ActionContext, payload: any) {
  const uid = requireAccountIdentity(ctx);
  await requireActiveProfileForWrite(ctx);
  const existing = await ctx.db.getRepository(UserAddress).findOneBy({ id: payload.id, uid });
  if (!existing) throw new AppError('NOT_FOUND', 'Address not found');
  await ctx.db.transaction(async (tx: EntityManager) => {
    await tx.getRepository(UserAddress).update({ uid }, { isDefault: false });
    await tx.getRepository(UserAddress).update({ id: payload.id, uid }, { isDefault: true });
  });
  return { defaultAddressId: payload.id };
}

export async function storesList(ctx: ActionContext) {
  const stores = await ctx.db.getRepository(Store).find({ where: { status: 'active' }, order: { updatedAt: 'DESC' as any } });
  return { stores };
}

export async function storesGet(_ctx: ActionContext, payload: any) {
  const store = await _ctx.db.getRepository(Store).findOneBy({ id: payload.storeId, status: 'active' });
  if (!store) throw new AppError('NOT_FOUND', 'Store not found');
  return { store };
}

export async function storeContextGetMyStore(ctx: ActionContext) {
  const context = await ctx.db.getRepository(UserStoreContext).findOneBy({ uid: ctx.uid! });
  return { context };
}

export async function storeContextSetMyStore(ctx: ActionContext, payload: any) {
  const store = await ctx.db.getRepository(Store).findOneBy({ id: payload.storeId, status: 'active' });
  if (!store) throw new AppError('VALIDATION_ERROR', 'Store is not active');
  await ctx.db.transaction(async (tx: EntityManager) => {
    await tx.getRepository(UserStoreContext).upsert({ uid: ctx.uid!, storeId: payload.storeId }, ['uid']);
  });
  return { context: await ctx.db.getRepository(UserStoreContext).findOneBy({ uid: ctx.uid! }) };
}

export async function mediaCreateUploadSpec(ctx: ActionContext, payload: any) {
  return ctx.db.transaction(async (tx: EntityManager) => {
    return createMediaUploadSpec({
      tx,
      storeId: ctx.storeId ?? null,
      ownerType: payload.ownerType,
      ownerId: payload.ownerId,
      kind: payload.kind,
      fileExt: payload.fileExt,
      contentType: payload.contentType,
      sizeBytes: payload.sizeBytes,
      createdByUid: ctx.uid!,
      finalizeAction: 'mediaFinalizeUpload',
    });
  });
}

export async function mediaFinalizeUpload(ctx: ActionContext, payload: any) {
  const repo = ctx.db.getRepository(MediaAsset);
  const asset = await repo.findOne({ where: { id: payload.assetId } });
  if (!asset) throw new AppError('NOT_FOUND', 'Asset not found');
  if (asset.createdByUid !== ctx.uid) throw new AppError('FORBIDDEN', 'Asset does not belong to caller');

  const bucketName = getBucketName();
  const [metadata] = await getStorage().bucket(bucketName).file(asset.originalPath).getMetadata();
  const size = Number(metadata.size || 0);
  if (size > Number(asset.sizeBytes)) {
    throw new AppError('VALIDATION_ERROR', 'Uploaded size exceeds requested size', { requested: asset.sizeBytes, actual: size });
  }
  if (metadata.contentType !== asset.contentType) {
    throw new AppError('VALIDATION_ERROR', 'Uploaded content type mismatch', { requested: asset.contentType, actual: metadata.contentType });
  }

  await ctx.db.transaction(async (tx: EntityManager) => {
    await tx.getRepository(MediaAsset).update(asset.id, {
      contentType: metadata.contentType || asset.contentType,
      sizeBytes: String(size),
      status: asset.kind === 'image' ? 'processing' : 'ready',
    });
  });

  const updated = await repo.findOneByOrFail({ id: asset.id });
  return {
    asset: {
      id: updated.id,
      originalPath: updated.originalPath,
      thumbnailPath: updated.thumbnailPath ?? undefined,
      status: updated.status,
      contentType: updated.contentType,
      sizeBytes: Number(updated.sizeBytes),
      kind: updated.kind,
      ownerType: updated.ownerType,
      ownerId: updated.ownerId,
      storeId: updated.storeId ?? undefined,
    },
  };
}
