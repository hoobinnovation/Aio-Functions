export const CLIENT_ACTIONS_SOT = [
    'clientHealthWhoAmI',
    'clientActionsList',
    'authEnsureUserProfile',
    'authPhonePasswordRegister',
    'authPhonePasswordLogin',
    'authProvidersGet',
    'authSetPhonePassword',
    'profileGet',
    'profileUpdate',
    'accountDeleteRequest',

    'addressesList',
    'addressesCreate',
    'addressesUpdate',
    'addressesDelete',
    'addressesSetDefault',

    'storesList',
    'storesGet',
    'storeContextGetMyStore',
    'storeContextSetMyStore',

    'homeGetLayout',
    'catalogGetCategories',
    'catalogListProducts',
    'productFavoritesList',
    'productFavoritesToggle',
    'storeFavoritesList',
    'storeFavoritesToggle',

    'cartGet',
    'cartAddItem',
    'cartUpdateQty',
    'cartRemoveItem',
    'cartClear',
    'cartApplyCoupon',
    'cartRemoveCoupon',

    'shippingListMethods',
    'shippingQuoteDelivery',
    'checkoutPreview',

    'notificationsRegisterToken',
    'notificationsList',
    'notificationsMarkRead',
    'notificationsMarkAllRead',
    'notificationsDelete',

    'loyaltyGetDashboard',
    'loyaltyListTransactions',
    'loyaltyRedeem',

    'walletGet',
    'walletHistory',

    'marketingCapture',

    'alertsGetPrefs',
    'alertsUpdatePrefs',
    'alertsSubscribeBackInStock',

    'recoGetSimilar',
    'recoGetCartUpsell',

    'postPurchaseGetNudges',

    'supportCreateTicket',
    'supportListTickets',
    'supportGetTicket',
    'supportAddMessage',
    'supportCloseTicket',

    'settingsGet',
    'settingsUpdate',
    'legalGetDocs',

    'mediaCreateUploadSpec',
    'mediaFinalizeUpload',

    'checkoutCreatePaymentSession',
    'paymentsStatus',
    'paymentsConfirm',

    'ordersList',
    'ordersGet',
    'ordersTracking',
    'ordersInvoiceUrl',
    'ordersReorder',

    'insuranceCreateDraft',
    'insuranceAttachFiles',
    'insuranceSubmit',
    'insuranceGet',
    'insuranceApproveQuote',
    'insuranceRejectQuote',
    'insuranceListMyOrders',
    'prescriptionCreateDraft',
    'prescriptionAttachFiles',
    'prescriptionSubmit',
    'prescriptionGet',
    'prescriptionListMine',
    'prescriptionCancel',
    'prescriptionGetWhatsAppContact',

    'dineInScanTableCode',
    'dineInGetSession',
    'dineInCloseSession',
    'dineInCallWaiter',
    'dineInRequestBill',

    'reviewsCanReview',
    'reviewsCreate',
] as const;
